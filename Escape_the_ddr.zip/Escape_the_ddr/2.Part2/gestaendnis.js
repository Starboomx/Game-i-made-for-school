const canvas = document.getElementById("targetCanvas"); //jetzt schon kb mehr
const ctx = canvas.getContext("2d");
const scoreElement = document.getElementById("score");
const resultElement = document.getElementById("result");
const startButton = document.getElementById("startButton");

const targetGoal = 20; 
let targets = [];
let score = 0;
let targetInterval, drawInterval; 
function createTarget() {
    const x = Math.random() * (canvas.width - 30);
    const y = Math.random() * (canvas.height - 30);
    targets.push({ x, y, size: 50 });
    setTimeout(() => {
        const index = targets.findIndex(target => target.x === x && target.y === y);
        if (index > -1) targets.splice(index, 1);
    }, 2000); 
}

function drawTargets() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    targets.forEach(target => {
        ctx.fillStyle = "black";
        ctx.fillRect(target.x, target.y, target.size, target.size);
    });
}

canvas.addEventListener("click", event => {
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    let hit = false;

    
    targets.forEach((target, index) => {
        if (x >= target.x && x <= target.x + target.size && y >= target.y && y <= target.y + target.size) {
            targets.splice(index, 1);
            score++;
            updateScore();
            hit = true;
            if (score === targetGoal) {
                gameWon();
            }
        }
    });

    // ich hasse mathe
    if (!hit) {
        gameLost();
    }
});

function updateScore() {
    scoreElement.textContent = `${score}/${targetGoal}`;
}

function gameWon() {
    clearInterval(targetInterval);
    clearInterval(drawInterval);
    resultElement.innerHTML = `<button class="button" onclick="nextPart()">Geschafft!</button>`;
}

function gameLost() {
    clearInterval(targetInterval);
    clearInterval(drawInterval);
    resultElement.innerHTML = `<button class="button" onclick="retry()">Verloren</button>`;
}

function nextPart() {
    
    window.location.href = "/2.Part3/gewonnen.html"; 
}

function retry() {
    
    window.location.href = "/Endings/Aufgeben.html"; 
}

function startGame() {
    startButton.style.display = "none"; 
    canvas.style.display = "block"; 
    scoreElement.style.display = "block"; 

    targetInterval = setInterval(() => {
        if (targets.length < 5) createTarget();
    }, 800); 

    drawInterval = setInterval(drawTargets, 50);
    updateScore();
}


startButton.addEventListener("click", startGame);
//endlich. https://www.youtube.com/watch?v=dQw4w9WgXcQ